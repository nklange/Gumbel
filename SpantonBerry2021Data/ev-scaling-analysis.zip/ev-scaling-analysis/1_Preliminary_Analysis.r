## Preliminary Analysis and Exclusions

rm(list=ls())

library(tidyverse)
library(data.table)
library(psych)

# Assign Experiment data to analyse
expt <- "Experiment2"

# Get a list of all csvs in rawdata directory
csvlist <- list.files(path=paste0(getwd(), "/rawdata/", expt, "/"))
# Import all data files into a list without prints
alldata <- map(csvlist, ~ read_csv(paste0(getwd(), "/rawdata/", expt, "/", .x)) )

# Set n participants by length of list
nppts <- length(csvlist)

# Age/Gender analysis ---------------
agegen <- map_dfr(alldata, ~ slice(.x, (n()-2):n())) %>%
  filter(correct != "undefined") %>%
  dplyr::select(subject_nr, response)

# Get descriptives for age
descage <- agegen %>%
  filter(nchar(response) == 2 & response != "no") %>%
  arrange(subject_nr) %>%
  summarise(
    meanage = mean(as.numeric(response)),
    sdage = sd(as.numeric(response))
  )

# Get counts for gender
descgender <- agegen %>%
  filter(nchar(response) > 2) %>%
  summarise(
    countm = sum(response == "Male"),
    countf = sum(response == "Female"),
    counto = sum(response == "Other"),
    countna = sum(response == "I'd rather not say")
  )

write_csv(descage, paste0(getwd(), "/output/", expt, "/age.csv"))
write_csv(descgender, paste0(getwd(), "/output/", expt, "/gender.csv"))

# Study phase data analysis --------------

# Filter study data, get only conditions where 1back task happened, group
studydata <- map(alldata, ~ filter(.x, phase == "study")) %>%
  map(~ filter(.x, condition == "C" | condition == "D")) %>%
  map(~ dplyr::select(.x, subject_nr, phase, condition, target, nbackdigit,
                      response, response_time, correct, total_responses, total_correct)) %>%
  map(~ group_by(.x, subject_nr)) %>%
  reduce(bind_rows)

# Output study data
studydata %>%
  arrange(subject_nr) %>%
  write_csv(paste0(getwd(), "/output/", expt, "/all_raw_study_data.csv"))

# Do an exclusion check on study phase performance
propcorr <- studydata %>%
  summarise(pc = sum(correct == 1)/length(correct)) %>%
  #mutate(excl = pc < mean(pc)-(sd(pc)*3)) Old performance measure: not psychologically meaningful
  mutate(excl = pc <= 0.5)
  
cat(sum(propcorr$excl == T), "participant(s) with low study phase task performance:",
    which(propcorr$excl == T), "\n")

## Test phase data analysis and exclusions ------------------

# Filter to study phase, select correct variables
testdata <- map(alldata, ~ filter(.x, phase == "test")) %>%
  map(~ dplyr::select(.x, subject_nr, phase, condition, test_word, oldnew, response, 
                      correct_response, correct, response_time, total_responses, total_correct)) %>%
  map(~ slice(.x, 1:480)) %>%
  map(~ group_by(.x, condition))

## Define functions that pertain to criterion estimation
est_criteria <- function(PN1, PN2, PN3, PN4, PN5, PN6) {
  probs <- c(PN1, PN2, PN3, PN4, PN5, PN6)
  cprobs <- rev(cumsum(rev(probs)))[2:6]
  
  for (i in 1:5) {
    if (cprobs[i] == 0) {
      cprobs[i] <- 1 / 60
    }
    if (cprobs[i] == 1) {
      cprobs[i] <- 1-(1/60)
    }
  }
  
  e.c <- vector()
  e.c[1] <- qnorm(1 - cprobs[1])
  e.c[2] <- qnorm(1 - cprobs[2]) - qnorm(1 - cprobs[1])
  e.c[3] <- qnorm(1 - cprobs[3]) - qnorm(1 - cprobs[2])
  e.c[4] <- qnorm(1 - cprobs[4]) - qnorm(1 - cprobs[3])
  e.c[5] <- qnorm(1 - cprobs[5]) - qnorm(1 - cprobs[4])
  
  return(e.c)
}

# Define function that calculates d from hits and false alarms
est_d <- function(HitRate, FARate) {
  
  e.d <- qnorm(HitRate) - qnorm(FARate)
  
  if (is.infinite(e.d) == T | is.na(e.d) == T | e.d < 0) {
    return(0.5)
  } else {
    return(e.d)
  }
  
}

# Analyse data to get key indices
testres <- testdata %>% 
  map(~ summarise(.x, participant = subject_nr[1],
                  # Probability of each response
                  PN1 = sum(oldnew == 0 & response == 1)/sum(oldnew),
                  PN2 = sum(oldnew == 0 & response == 2)/sum(oldnew),
                  PN3 = sum(oldnew == 0 & response == 3)/sum(oldnew),
                  PN4 = sum(oldnew == 0 & response == 4)/sum(oldnew),
                  PN5 = sum(oldnew == 0 & response == 5)/sum(oldnew),
                  PN6 = sum(oldnew == 0 & response == 6)/sum(oldnew),
                  PO1 = sum(oldnew == 1 & response == 1)/sum(oldnew),
                  PO2 = sum(oldnew == 1 & response == 2)/sum(oldnew), 
                  PO3 = sum(oldnew == 1 & response == 3)/sum(oldnew),
                  PO4 = sum(oldnew == 1 & response == 4)/sum(oldnew),
                  PO5 = sum(oldnew == 1 & response == 5)/sum(oldnew),
                  PO6 = sum(oldnew == 1 & response == 6)/sum(oldnew),
                  # Hit and FA rates
                  HitRate = sum(PO4*sum(oldnew), PO5*sum(oldnew), PO6*sum(oldnew)) / sum(oldnew),
                  FARate = sum(PN4*sum(oldnew), PN5*sum(oldnew), PN6*sum(oldnew)) / sum(oldnew),
                  Pr = HitRate - FARate,
                  # Parameter starting estimates
                  e.d = est_d(HitRate, FARate),
                  e.sigo = 1.25,
                  e.c1 = est_criteria(PN1, PN2, PN3, PN4, PN5, PN6)[1],
                  e.dc1 = est_criteria(PN1, PN2, PN3, PN4, PN5, PN6)[2],
                  e.dc2 = est_criteria(PN1, PN2, PN3, PN4, PN5, PN6)[3],
                  e.dc3 = est_criteria(PN1, PN2, PN3, PN4, PN5, PN6)[4],
                  e.dc4 = est_criteria(PN1, PN2, PN3, PN4, PN5, PN6)[5]
  ))


# Check for low recognition memory performance in at least two conditions
PrChk <- map_lgl(testres, ~ sum(.x$Pr < 0) >= 2)
cat(sum(PrChk == T), "participant(s) with low recognition memory performance:", 
    which(PrChk == T), "\n")

# Check for a binary response pattern at test
BinChk <- map_lgl(testres, ~ any(.x$PN1 + .x$PN6 == 1 & .x$PO1 + .x$PO6 == 1))
cat(sum(BinChk == T), "participant(s) with binary response patterns:", 
    which(BinChk == T), "\n")

## zROC analysis -----
testres <- testres %>% reduce(bind_rows)

getprobs <- function(row) {
  probs <- testres[row,] %>%
    dplyr::select(PN1, PN2, PN3, PN4, PN5, PN6, PO1, PO2, PO3, PO4, PO5, PO6) %>%
    slice(1) %>%
    unlist(use.names=F)
  
  return(probs)
}

# Calculate zROC slope function
calc_slope <- function(zNs, zOs) {
  if (any(is.infinite(c(zNs, zOs)) == T)) {
    zslope <- NA
  } else {
    zslope <- round(lm(zOs ~ zNs)$coef[2], digits = 2)
  }
  
  return(zslope)
}

# Apply probs function to data
probs <- map(1:length(testres$participant), ~ getprobs(.x))

zNs <- map(probs, ~.x[1:6]) %>%
  map(~rev(cumsum(rev(.x)))[2:6]) %>%
  map(~qnorm(.x))

zOs <- map(probs, ~.x[7:12]) %>%
  map(~rev(cumsum(rev(.x)))[2:6]) %>%
  map(~qnorm(.x))

testres$zslope <- map2_dbl(zNs, zOs, ~calc_slope(.x, .y))

testres %>% 
  arrange(participant) %>%
  write_csv(paste0(getwd(), "/output/", expt, "/all_analysed_test_data.csv"))

all_rawdata <- reduce(testdata, bind_rows) %>%
  arrange(subject_nr) %>%
  write_csv(paste0(getwd(), "/output/", expt, "/all_raw_test_data.csv"))
