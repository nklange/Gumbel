### EV-SCALING ANALYSIS README ###

This directory contains the analyses reported in "Variability in recognition memory scales with mean memory strength: implications for the encoding variability hypothesis" by Spanton and Berry. 

The analyses are stored in four R scripts, each of which are designed to be run sequentially (and numbered as such). To reproduce the analyses for either experiment:

1. Ensure you're working in the ev-scaling-analysis R project.
2. Install any packages required to run each script.
3. Define the experiment you wish to analyse by changing the value assigned to the expt variable at the top of each script to either "Experiment1" or "Experiment2".
4. Run the script(s).

Some parts of the analysis use simulation, for example as part of the parameter estimation routine and the calculation of Bayes Factors with the BayesFactor package. This may result in small discrepancies between some parameter estimates and Bayes Factors generated upon reproduction and those reported in the paper, though these discrepancies will be small and trends in the results will remain the same.

Descriptions of output variables can be found in code comments within each analysis script.

For any further questions about the analyses in this repository, please contact Rory Spanton, the first author.