## 2. Data Analysis

rm(list=ls())

library(tidyverse)
library(afex)
library(BayesFactor)
library(cowplot)
library(wesanderson)

# Source the flat violin function from a separate doc
source("R_raincloudfunction.r")

# Define a 'not in' function (really useful for filtering)
"%notin%" <- Negate("%in%")

# Point program at either Experiment1 or Experiment2
expt <- "Experiment2"

# Read in data files
all_study_raw     <- read_csv(paste0(getwd(), "/output/", expt, "/all_raw_study_data.csv"))
all_test_raw      <- read_csv(paste0(getwd(), "/output/", expt, "/all_raw_test_data.csv"))
all_test_analysed <- read_csv(paste0(getwd(), "/output/", expt, "/all_analysed_test_data.csv"))
all_fits          <- read_csv(paste0(getwd(), "/output/", expt, "/all_fits.csv"))
# age               <- read_csv(paste0(getwd(), "/output/", expt, "/age.csv"))
# gender            <- read_csv(paste0(getwd(), "/output/", expt, "/gender.csv"))

# Take log of sigo
all_fits$logsigo <- log(all_fits$sigo)

# Do listwise exclusion of outlying parameter value participants
to_excl <- all_fits %>% filter(sigo >= mean(sigo)+(sd(sigo)*3) | d >= mean(d)+(sd(d)*3))

# Exclude outlying participants from all datasets
all_study_raw     <- filter(all_study_raw, subject_nr %notin% unique(to_excl$participant))
all_test_raw      <- filter(all_test_raw, subject_nr %notin% unique(to_excl$participant))
all_test_analysed <- filter(all_test_analysed, participant %notin% unique(to_excl$participant))
all_fits          <- filter(all_fits, participant %notin% unique(to_excl$participant))

# Set number of participants for different analyses
nppts <- length(unique(all_fits$participant))

## Study phase descriptives and comparisons --------------
  
# Get propcorrect on a participant level, then t.test
forttest <- all_study_raw %>%
  group_by(subject_nr, condition) %>%
  summarise(propcorr = sum(correct)/length(correct))

pcLowStrHighEV <- filter(forttest, condition == "C")
pcLowStrLowEV <- filter(forttest, condition == "D")

studyt <- t.test(pcLowStrHighEV$propcorr, pcLowStrLowEV$propcorr, paired=T, alternative="t")
studyt_BF <- ttest.tstat(t=studyt$statistic, n1=nppts, rscale=0.707, simple=T)

## Table of parameter estimates --------------

table_estimates <- all_fits %>% 
  group_by(condition) %>%
  summarise(
    mean_d = mean(d),
    sd_d = sd(d),
    mean_sigo = mean(sigo),
    sd_sigo = sd(sigo),
    mean_logsigo = mean(logsigo),
    sd_logsigo = sd(logsigo),
    mean_c1 = mean(c1),
    sd_c1 = sd(c1),
    mean_c2 = mean(c2),
    sd_c2 = sd(c2),
    mean_c3 = mean(c3),
    sd_c3 = sd(c3),
    mean_c4 = mean(c4),
    sd_c4 = sd(c4),
    mean_c5 = mean(c5),
    sd_c5 = sd(c5)
  )

## Multiple regression analysis: ---------

# Read ev_words
high_ev_words <- read_csv(paste(getwd(), "/words/", expt, "/high_ev_words.csv", sep=""))
low_ev_words <- read_csv(paste(getwd(), "/words/", expt, "/low_ev_words.csv", sep=""))
# Bind word indices tbls
ev_words <- bind_rows(high_ev_words, low_ev_words)

# Join raw test data with words tbl
t <- all_test_raw %>%
  rename("Spelling" = test_word) %>%
  inner_join(ev_words, by="Spelling") %>%
  filter(oldnew == 1) %>% # Filter to keep only old items
  mutate(wordlength = nchar(Spelling)) # Make a character length column

# Define function for extracting regression ANOVA p value
lmp <- function (modelobject) {
  # Check for class lm
  if (class(modelobject) != "lm") stop("Not an object of class 'lm' ")
  # Get f statistics
  ff <- summary(modelobject)$fstatistic
  # Get probability value based on f distribution
  p <- pf(ff[1],ff[2],ff[3],lower.tail=F)
  attributes(p) <- NULL
  return(p)
}

# Get R^2 for each participant
getRsq <- function(data) {
  fits <- list()
  k <- 0
  
  for (ppt in unique(data$subject_nr)) {
    # Debug
    assign("ppt", ppt, envir=.GlobalEnv)
    k <- k + 1
    
    # Filter data by participant, select relevant variables
    f <- data %>%
      filter(subject_nr == ppt) %>%
      dplyr::select(response, Zipf, Conc, AOA, wordlength)
    
    ## Do a multiple regression
    # y ~ x1 + x2 + ... xn = "response = y + b1*x1 + b2*x2 + ... + bn*xn"
    fit <- lm(f$response ~ f$Zipf + f$Conc + f$AOA + f$wordlength)
    sigpr <- summary(fit)$coefficients %>% 
      as_tibble()
    
    # Append list of predictors to regression summary
    if (is.na(fit$coefficients[5]) == T) {
      sigpr$predictor = c("Intercept", "Zipf", "Conc", "AOA")
    } else {
      sigpr$predictor = c("Intercept", "Zipf", "Conc", "AOA", "wordlength")
    }
    
    # Check which predictors were significant, list these
    if (any(sigpr$`Pr(>|t|)` < 0.05)) {
      sigpr <- filter(sigpr, `Pr(>|t|)` < 0.05)
      sp <- paste(sigpr$predictor, collapse = ", ")
    } else {
      sp <- "None"
    }
    
    # Bind results together
    res <- tibble(
      Rsq_all = summary(fit)$r.squared,
      pval_all = lmp(fit),
      sigpredictors = sp
    )
    
    # Assign results to list item
    fits[[k]] <- res
  }
  
  return(fits)
}

# Get regression results in each condition using above function
fits <- getRsq(filter(t, condition == "A")) %>%
  append(getRsq(filter(t, condition == "B"))) %>%
  append(getRsq(filter(t, condition == "C"))) %>%
  append(getRsq(filter(t, condition == "D")))

# Clean up regression results into a tibble
regression_results <- tibble(
  subject_nr = rep(unique(t$subject_nr), 4),
  condition = c(rep("A", nppts), rep("B", nppts), rep("C", nppts), rep("D", nppts)),
  full_Rsq = map_dbl(fits, "Rsq_all"),
  sigpredictors = map_chr(fits, "sigpredictors"),
  pval_all = map_dbl(fits, "pval_all"),
  d = all_fits$d,
  logsigo = all_fits$logsigo
)

# Create table with mean R^2 and proportion of significant regressions
table_regression <- regression_results %>%
  group_by(condition) %>%
  summarise(
    `*P*(significant)` = sum(pval_all < 0.05)/length(pval_all),
    `Mean *R*^2^` = mean(full_Rsq),
    `SD *R*^2^` = sd(full_Rsq)
  )

# Do anova with Rsq as dependent variable (strength/enc var as factors)
foranova <- regression_results %>%
  transmute(
    participant = as_factor(subject_nr),
    condition = condition,
    strength = c(rep("high", nppts*2), rep("low", nppts*2)), 
    enc_var = rep(c(rep("high", nppts), rep("low", nppts)), 2),
    strength = as_factor(strength),
    enc_var = as_factor(enc_var),
    full_Rsq = full_Rsq,
  )

# Run ANOVA
rsqANOVA <- afex::aov_ez(id = "participant",
                         dv = "full_Rsq",
                         data = foranova,
                         within=c("strength", "enc_var"),
                         anova_table=list(es="pes"))

# Get BFs for ANOVA
rsqANOVA_BF  <- anovaBF(full_Rsq ~ strength * enc_var + participant, data = foranova, whichRandom = "participant")
rsqANOVA_intBF <- rsqANOVA_BF[4]/rsqANOVA_BF[3]

## ANOVA: Strength x EV w/ d as dependent -----------------

# Arrange data with outliers included...
foranova <- all_test_analysed %>%
  full_join(all_fits) %>% 
  dplyr::select(condition, participant, d, sigo) %>%
  mutate(strength = rep(c("high", "high", "low", "low"), nppts), 
         enc_var = rep(c("high", "low", "high", "low"), nppts),
         strength = as_factor(strength),
         enc_var = as_factor(enc_var),
         participant = as_factor(participant)
         )

# Run ANOVA: IVs: str, enc_var. DV: Pr
strEV_anova <- afex::aov_ez(id = "participant",
                            dv = "d",
                            data = foranova,
                            within=c("strength", "enc_var"),
                            anova_table=list(es="pes"))

# Get BFs for above ANOVA
strEV_BF  <- anovaBF(d ~ strength * enc_var + participant, data = foranova, whichRandom = "participant")
strEV_intBF <- strEV_BF[4]/strEV_BF[3] # for interaction BF

## ANOVA: Strength x EV w/ sigo as dependent -----------------

# Arrange data for ANOVA with outliers included...
foranova <- all_test_analysed %>%
  full_join(all_fits) %>% 
  dplyr::select(condition, participant, logsigo) %>%
  mutate(strength = rep(c("high", "high", "low", "low"), nppts), 
         enc_var = rep(c("high", "low", "high", "low"), nppts),
         strength = as_factor(strength),
         enc_var = as_factor(enc_var),
         participant = as_factor(participant)
  )

# Run ANOVA on sigma old with str and enc var as factors
sigoANOVA <- afex::aov_ez(id = "participant",
                          dv = "logsigo",
                          data = foranova,
                          within=c("strength", "enc_var"),
                          anova_table=list(es="pes"))

# Get BFs for above ANOVA
sigoANOVA_BF  <- anovaBF(logsigo ~ strength * enc_var + participant, data = foranova, whichRandom = "participant")
sigoANOVA_intBF <- sigoANOVA_BF[4]/sigoANOVA_BF[3] # for interaction BF

## Exploratory: zROC slope analysis -----------

# Get all zslope estimates of sigo alongside fit estimates
z_sigoests <- all_test_analysed %>%
  dplyr::select(participant, condition, zslope) %>% 
  arrange(condition) %>%
  mutate(sigo_z = 1/zslope,
         sigo_fit = all_fits$sigo) %>%
  filter(is.na(zslope) == F)

# Graph z sigo against fit sigo
# This shows parity between model and zROC estimates of sigma old
z_sigoests %>% 
  ggplot(aes(x=sigo_z, y=sigo_fit)) + 
  geom_point() + 
  geom_smooth(method="lm", level=0)

## Raincloud Plots -------------

# Define values for raincloud plot
forraincloud <- all_fits %>%
  select(participant, condition, d, sigo) %>% 
  pivot_longer(cols = one_of("d", "sigo")) %>%
  rename(parameter = name)

raincloud_theme = theme(
  text = element_text(size = 10),
  axis.title.x = element_text(size = 16),
  axis.title.y = element_text(size = 16),
  axis.text = element_text(size = 14),
  # axis.text.x = element_text(angle = 15, vjust = 0.5),
  legend.title=element_text(size=16),
  legend.text=element_text(size=16),
  legend.position = "none",
  plot.title = element_text(lineheight=.8, face="bold", size = 16),
  panel.border = element_blank(),
  panel.grid.minor = element_blank(),
  panel.grid.major = element_blank(),
  axis.line.x = element_line(colour = 'black', size=0.5, linetype='solid'),
  axis.line.y = element_line(colour = 'black', size=0.5, linetype='solid'))

# Raincloud for d, with best fit colouration
raincloud <- ggplot(forraincloud, aes(x = condition, y = value, fill = condition)) +
  scale_fill_manual(values=wes_palette(name="Zissou1")) +
  geom_flat_violin(position = position_nudge(x = .2, y = 0), alpha = .8, color = NA) +
  geom_point(aes(y = value), position = position_jitter(width = .15), size = 2, alpha = .5) +
  geom_boxplot(width = .1, color = "black", outlier.shape = NA, alpha = .5) +
  facet_wrap(~ parameter) +
  xlab("Condition") + ylab("Parameter Estimate") +
  # ylim(0, 4) +
  theme_bw() +
  coord_flip() +
  scale_x_discrete(labels=c("High Strength,\nHigh EV",
                            "High Strength,\nLow EV",
                            "Low Strength,\nHigh EV",
                            "Low Strength,\nLow EV")) +
  raincloud_theme

## Exploratory: Curve fitting --------------------

fitdata <- all_fits

# Fit a linear model sigo ~ d
poly1 <- map(c("A", "B", "C", "D"), ~ filter(fitdata, fitdata$condition == .x)) %>%
  map(~ lm(logsigo ~ d, data = .x))

# Fit a linear + quadratic model sigo ~ d + d^2
poly2 <- map(c("A", "B", "C", "D"), ~ filter(fitdata, fitdata$condition == .x)) %>%
  map(~ lm(logsigo ~ poly(d, 2), data = .x))

poly3 <- map(c("A", "B", "C", "D"), ~ filter(fitdata, fitdata$condition == .x)) %>%
  map(~ lm(logsigo ~ poly(d, 3), data = .x))
  
# Compare the linear and linear+quadratic models using anova
anova12 <- map2(poly1, poly2, ~ anova(.x, .y))
anova23 <- map2(poly2, poly3, ~ anova(.x, .y))

# Mutate allfits to include polynomial terms for use with lmBF
fitdata <- mutate(fitdata, d2 = poly(d, 2)[,"2"],
                   d3 = poly(d, 3)[,"3"])

# Get BFs for linear, linear + polynomial terms
poly1BF <- map(c("A", "B", "C", "D"), ~ filter(fitdata, fitdata$condition == .x)) %>%
  map(~ lmBF(logsigo ~ d, data = as.data.frame(.x)))

poly2BF <- map(c("A", "B", "C", "D"), ~ filter(fitdata, fitdata$condition == .x)) %>%
  map(~ lmBF(logsigo ~ d + d2, data = as.data.frame(.x)))

poly3BF <- map(c("A", "B", "C", "D"), ~ filter(fitdata, fitdata$condition == .x)) %>%
  map(~ lmBF(logsigo ~ d + d2 + d3, data = as.data.frame(.x)))

# Map BF comparisons (for evaluating improvements in fit as result of added complexity)
map2(poly1BF, poly2BF, ~ .y/.x)
map2(poly2BF, poly3BF, ~ .y/.x)

# Store curve fitting routine results 
curveresults <- tibble(
  conditions = c("High Strength, High EV", "High Strength, Low EV", "Low Strength, High EV", "Low Strength, Low EV"),
  Rsq_poly1 = map_dbl(poly1, ~ summary(.x)$r.squared),
  p_poly1 = map_dbl(poly1, ~ round(lmp(.x), digits=3)),
  Rsq_poly2 = map_dbl(poly2, ~ summary(.x)$r.squared),
  p_poly2 = map_dbl(poly2, ~ round(lmp(.x), digits=3)),
  Rsq_poly3 = map_dbl(poly3, ~ summary(.x)$r.squared),
  p_poly3 = map_dbl(poly3, ~ round(lmp(.x), digits=3)),
  Rsq_diff_1_2 = Rsq_poly2 - Rsq_poly1,
  sig_1_2 = map_dbl(anova12, ~ round(.x$`Pr(>F)`[2], digits=3)),
  Rsq_diff_2_3 = Rsq_poly3 - Rsq_poly2,
  sig_2_3 = map_dbl(anova23, ~ round(.x$`Pr(>F)`[2], digits=3))
)
