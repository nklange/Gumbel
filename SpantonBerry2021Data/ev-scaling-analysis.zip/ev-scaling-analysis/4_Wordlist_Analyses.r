## Words means and intercorrelations

rm(list=ls())

library(tidyverse)

E1Words_hi <- read_csv(paste0(getwd(), "/words/Experiment1/high_ev_words.csv"))
E1Words_lo <- read_csv(paste0(getwd(), "/words/Experiment1/low_ev_words.csv"))
E2Words_hi <- read_csv(paste0(getwd(), "/words/Experiment2/high_ev_words.csv"))
E2Words_lo <- read_csv(paste0(getwd(), "/words/Experiment2/low_ev_words.csv"))

# Get table of encoding variable means and sds for each word list
words_table <- bind_rows(E1Words_hi, E1Words_lo, E2Words_hi, E2Words_lo) %>%
  dplyr::select(Spelling, Zipf, Conc, AOA) %>%
  mutate(
    cond = c(rep("E1_hi", 240), rep("E1_lo", 240), rep("E2_hi", 240), rep("E2_lo", 240)),
    wlist = rep(c(rep("1", 60), rep("2", 60), rep("3", 60), rep("4", 60)), 4)
    ) %>%
  group_by(cond, wlist) %>%
  summarise(
    meanZipf = mean(Zipf),
    sdZipf = sd(Zipf),
    meanConc = mean(Conc),
    sdConc = sd(Conc),
    meanAOA = mean(AOA),
    sdAOA = sd(AOA),
    cor_ZipfConc = unlist(cor.test(Zipf, Conc)[4]),
    cor_ZipfAOA = unlist(cor.test(Zipf, AOA)[4]),
    cor_ConcAOA = unlist(cor.test(Conc, AOA)[4])
  )

words_table