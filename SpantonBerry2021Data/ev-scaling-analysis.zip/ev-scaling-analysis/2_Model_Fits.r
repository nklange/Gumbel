# Data preprocessing and initial analysis

rm(list=ls())

library(tidyverse)
library(data.table)
library(psych)
library(tictoc)

set.seed(123)

expt <- "Experiment2"

# Define number of optimisation attempts for parameter estimation
optreps <- 20

# Load analysed test data
all_testdata <- read_csv(paste0(getwd(), "/output/", expt, "/all_analysed_test_data.csv"))

nppts <- length(unique(all_testdata$participant))

# Filter data by condition
dataA <- all_testdata %>%
  filter(condition == "A")
dataB <- all_testdata %>%
  filter(condition == "B")
dataC <- all_testdata %>%
  filter(condition == "C")
dataD <- all_testdata %>%
  filter(condition == "D")

## Model fit procedure ------------------------

# Define likelihood function to be optimised
optfun  <- function(par, data){
  
  DataN <- c(data$PN1*60, data$PN2*60, data$PN3*60, 
             data$PN4*60, data$PN5*60, data$PN6*60)
  DataO <- c(data$PO1*60, data$PO2*60, data$PO3*60,
             data$PO4*60, data$PO5*60, data$PO6*60)
  
  d     <- exp(par[1])
  sigo  <- exp(par[2])
  c     <- vector()
  c[1]  <- par[3]
  c[2]  <- c[1] + exp(par[4])
  c[3]  <- c[2] + exp(par[5])
  c[4]  <- c[3] + exp(par[6])
  c[5]  <- c[4] + exp(par[7])
  
  # Constraints
  sign  <- 1  
  I <- c(-Inf,c,Inf) # put criteria into larger array
  
  # Likelihood of every trial 
  # New items
  NlikJ <- vector()
  for (i in 1:length(DataN)){
    NlikJ[i] <- DataN[i] * log( pnorm(I[i+1],mean=0,sd=sign)-pnorm(I[i],mean=0,sd=sign) )
  }
  
  # Old items
  OlikJ <- vector()
  for (i in 1:length(DataO)){
    OlikJ[i] <- DataO[i] * log( pnorm(I[i+1],mean=d,sd=sigo)-pnorm(I[i],mean=d,sd=sigo) )
  }
  return( -sum(c(NlikJ,OlikJ)) )
}

# Define function to generate starting parameter estimates for optimisation
gen_pstart <- function(x, ppt) {
  transformlist = c("TMPd", "TMPsigo", "TMPdc1", "TMPdc2", "TMPdc3", "TMPdc4")
  
  # 20 sets of starting values estimated from the data
  pstart <- tibble(
    TMPd    = rnorm(optreps, mean=x$e.d[ppt], sd=0.2),
    TMPsigo = rnorm(optreps, mean=x$e.sigo[ppt], sd=0.2),
    TMPc1   = rnorm(optreps, mean=x$e.c1[ppt], sd=0.2),
    TMPdc1  = rnorm(optreps, mean=x$e.dc1[ppt], sd=0.2),
    TMPdc2  = rnorm(optreps, mean=x$e.dc2[ppt], sd=0.2),
    TMPdc3  = rnorm(optreps, mean=x$e.dc3[ppt], sd=0.2),
    TMPdc4  = rnorm(optreps, mean=x$e.dc4[ppt], sd=0.2)
  ) 
  
  # 10 sets of more "random" starting values, not tied to data estimates
  pstartunif <- tibble(
    TMPd    = runif(optreps/2, min=0, max=3),
    TMPsigo = runif(optreps/2, min=1, max=4),
    TMPc1   = runif(optreps/2, min=-2, max=0),
    TMPdc1  = runif(optreps/2, min=0, max=1),
    TMPdc2  = runif(optreps/2, min=0, max=1),
    TMPdc3  = runif(optreps/2, min=0, max=1),
    TMPdc4  = runif(optreps/2, min=0, max=1)
  )
  
  pstart <- bind_rows(pstart, pstartunif) %>%
    mutate_at(transformlist, ~ log(abs(.x)))
  
  return(pstart)
}

# Define function to extract and store fit data
extract_fits <- function(bestfit, data, cond) {
  
  f <- tibble(
    participant = ppt,
    condition = cond,
    # Estimated parameter values
    d     = exp(bestfit$par[1]),
    sigo  = exp(bestfit$par[2]),
    c1    = bestfit$par[3],
    c2    = c1 + exp(bestfit$par[4]),
    c3    = c2 + exp(bestfit$par[5]),
    c4    = c3 + exp(bestfit$par[6]),
    c5    = c4 + exp(bestfit$par[7]),
    # Log likelihood + information from fit procedure
    lglik = -bestfit$value,
    convr = bestfit$convergence,
    fn    = bestfit$counts[[1]],
    dpoints = 120, # Datapoints per test phase
    freep = 7, # Free parameters
    aic   = -2*(-bestfit$value) + 2*freep,
    bic   = -2*(-bestfit$value) + freep*log(dpoints),
    
    # Estimated frequencies of each response, according to model fit
    eN1 = pnorm(c1, mean=0, sd=1),
    eN2 = pnorm(c2, mean=0, sd=1) - pnorm(c1, mean=0, sd=1),
    eN3 = pnorm(c3, mean=0, sd=1) - pnorm(c2, mean=0, sd=1),
    eN4 = pnorm(c4, mean=0, sd=1) - pnorm(c3, mean=0, sd=1),
    eN5 = pnorm(c5, mean=0, sd=1) - pnorm(c4, mean=0, sd=1),
    eN6 = 1 - pnorm(c5, mean=0, sd=1),
    
    eO1 = pnorm(c1, mean=d, sd=sigo),
    eO2 = pnorm(c2, mean=d, sd=sigo) - pnorm(c1, mean=d, sd=sigo),
    eO3 = pnorm(c3, mean=d, sd=sigo) - pnorm(c2, mean=d, sd=sigo),
    eO4 = pnorm(c4, mean=d, sd=sigo) - pnorm(c3, mean=d, sd=sigo),
    eO5 = pnorm(c5, mean=d, sd=sigo) - pnorm(c4, mean=d, sd=sigo),
    eO6 = 1 - pnorm(c5, mean=d, sd=sigo),
    
    ezROCslp = 1/sigo, # Estimated zROC slope
  )
  
  if (cond == "A") {
    f$opt <- which.min(map_dbl(optA, "value"))
  } else if (cond == "B") {
    f$opt <- which.min(map_dbl(optB, "value"))
  } else if (cond == "C") {
    f$opt <- which.min(map_dbl(optC, "value"))
  } else {
    f$opt <- which.min(map_dbl(optD, "value"))
  }
  
  # Check that likelihood of estimated values sums to zero
  pchk <- c(log(f$d), log(f$sigo), f$c1, log(f$c2-f$c1),
            log(f$c3-f$c2), log(f$c4-f$c3), log(f$c5-f$c4))
  
  f$likchk <- f$lglik-(-optfun(pchk, data[ppt,]))
  
  # Get observed data from participant
  obsd <- data[ppt,] %>%
    dplyr::select(PN1, PN2, PN3, PN4, PN5, PN6, PO1, PO2, PO3, PO4, PO5, PO6) %>%
    transmute_all(~ .*60) %>%
    slice(1) %>%
    unlist(use.names=F)
  
  # Get expected data from participant
  expd <- c(f$eN1,f$eN2,f$eN3,f$eN4,f$eN5,f$eN6,
            f$eO1,f$eO2,f$eO3,f$eO4,f$eO5,f$eO6)*60
  
  f$GSq    <- 2*sum(obsd*log(obsd/expd)) # Calculate G^2 (better approximator to Chi-sq dist than Pearson Chi-Sq)
  f$df     <- length(obsd)-7-1            # df model (L&F,p.63) n_observations - n_freeparas - 1
  f$pGSq   <- 1-pchisq(f$GSq,f$df)       # p value of GSq
  
  return(f)
}

# Define function to run optimization procedure
run_optim <- function(pstart, data, optrep) {
  res <- optim(par=pstart[optrep,] %>% unlist(use.names=F), 
        optfun, 
        data = data[ppt,],
        method="Nelder-Mead",
        control=list(maxit=15000))
  
  return(res)
}

# Create lists to store best fits in
bfsA <- bfsB <- bfsC <- bfsD <- tibble()

# Generate starting parameters for every participant
pstartA <- map(1:nppts, ~ gen_pstart(dataA, .x))
pstartB <- map(1:nppts, ~ gen_pstart(dataB, .x))
pstartC <- map(1:nppts, ~ gen_pstart(dataC, .x))
pstartD <- map(1:nppts, ~ gen_pstart(dataD, .x))

# Start progress bar
cat("Model fit procedure in progress:\n")
pb <- txtProgressBar(min = 0, max = nppts, style = 3)
tic()

# Fit routine
for (ppt in 1:nppts) {
  
  # Do model fits for every participant
  optA <- map(1:(optreps*1.5), ~ run_optim(pstartA[[ppt]], dataA, .x))
  optB <- map(1:(optreps*1.5), ~ run_optim(pstartB[[ppt]], dataB, .x))
  optC <- map(1:(optreps*1.5), ~ run_optim(pstartC[[ppt]], dataC, .x))
  optD <- map(1:(optreps*1.5), ~ run_optim(pstartD[[ppt]], dataD, .x))
  
  # Store best fits for each condition
  minA <- optA[[which.min(map_dbl(optA, "value"))]]
  minB <- optB[[which.min(map_dbl(optB, "value"))]]
  minC <- optC[[which.min(map_dbl(optC, "value"))]]
  minD <- optD[[which.min(map_dbl(optD, "value"))]]
  
  # Extract data from current best fit, and bind to other data
  bfsA <- bfsA %>% bind_rows(extract_fits(bestfit = minA,
                                          cond = "A",
                                          data = dataA))
  bfsB <- bfsB %>% bind_rows(extract_fits(bestfit = minB,
                                          cond = "B",
                                          data = dataB))
  bfsC <- bfsC %>% bind_rows(extract_fits(bestfit = minC,
                                          cond = "C",
                                          data = dataC))
  bfsD <- bfsD %>% bind_rows(extract_fits(bestfit = minD,
                                          cond = "D",
                                          data = dataD))
  
  setTxtProgressBar(pb, ppt)
}

close(pb)
toc()

# Output
allres <- bind_rows(bfsA, bfsB, bfsC, bfsD)
write_csv(allres, paste(getwd(), "/output/", expt, "/all_fits.csv", sep=""))

